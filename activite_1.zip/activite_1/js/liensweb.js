/* 
Activité 1
*/

// Liste des liens Web à afficher. Un lien est défini par :
// - son titre
// - son URL
// - son auteur (la personne qui l'a publié)
var listeLiens = [
    {
        titre: "So Foot",
        url: "http://sofoot.com",
        auteur: "yann.usaille"
    },
    {
        titre: "Guide d'autodéfense numérique",
        url: "http://guide.boum.org",
        auteur: "paulochon"
    },
    {
        titre: "L'encyclopédie en ligne Wikipedia",
        url: "http://Wikipedia.org",
        auteur: "annie.zette"
    }
];

for (let i = 0; i < listeLiens.length; i++) {

let div = document.createElement("div")                            
div.id = listeLiens[i].titre;                                       
div.style.backgroundColor = 'white'                                 
div.style.marginTop = '30px'                                        

document.getElementById("contenu").appendChild(div)
                         
let lienElt = document.createElement("a");                          
lienElt.href = listeLiens[i].url;                                 
lienElt.textContent = listeLiens[i].titre;                                    
lienElt.style.color = "red";                                       
                                   
document.getElementById(listeLiens[i].titre) .appendChild(lienElt);           


let pElt = document.createElement("span");                          
pElt.textContent = listeLiens[i].url                              
pElt.style.marginLeft = '20px'                                      
document.getElementById(listeLiens[i].titre).appendChild(pElt)               




 let auteurElt = document.createElement("p") ;                        
 auteurElt.textContent = listeLiens[i].auteur;                      
 document.getElementById (listeLiens[i].titre) .appendChild(auteurElt);          

};

